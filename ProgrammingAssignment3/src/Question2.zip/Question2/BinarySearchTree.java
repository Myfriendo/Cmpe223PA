package Question2;

public class BinarySearchTree {

	//node class that defines BST node
	private static class Node { 
		int key;
		String name;
		String available;
		int star;
		Node left, right; 

		public Node(int key,String name,String available,int star){ 
			this.key = key; 
			this.name=name;
			this.available=available;
			this.star=star;
			this.left = this.right = null; 
		} 
	} 
	// BST root node 
	protected static Node root; 

	// Constructor for BST =>initial empty tree
	protected BinarySearchTree(){ 
		root = null; 
	} 
	//delete a node from BST
	public static void deleteKey(int key) { 
		root = delete_Recursive(root, key); 
	} 

	//recursive delete function
	protected static Node delete_Recursive(Node root, int key)  { 
		//tree is empty
		if (root == null)  return root; 

		//traverse the tree
		if (key < root.key)     //traverse left subtree 
			root.left = delete_Recursive(root.left, key); 
		else if (key > root.key)  //traverse right subtree
			root.right = delete_Recursive(root.right, key); 
		else  { 
			// node contains only one child
			if (root.left == null) 
				return root.right; 
			else if (root.right == null) 
				return root.left; 

			// node has two children; 
			//get inorder successor (min value in the right subtree) 
			root.key = minValue(root.right); 

			// Delete the inorder successor 
			root.right = delete_Recursive(root.right, root.key); 
		} 
		return root; 
	} 

	protected static int minValue(Node root)  { 
		//initially minval = root
		int minval = root.key; 
		//find minval
		while (root.left != null)  { 
			minval = root.left.key; 
			root = root.left; 
		} 
		return minval; 
	} 

	// insert a node in BST 
	protected static void insert(int key, String name, String available,int star)  { 
		root = insert_Recursive(root, key, name, available, star); 
	} 

	
	//recursive insert function
	protected static Node insert_Recursive(Node root, int key, String name, String available, int star) { 
		//tree is empty
		if (root == null) { 
			root = new Node(key, name, available, star); 
			return root; 
		} 
		//traverse the tree
		if (key < root.key)     //insert in the left subtree
			root.left = insert_Recursive(root.left, key, name, available, star); 
		else if (key > root.key)    //insert in the right subtree
			root.right = insert_Recursive(root.right, key, name, available, star); 
		// return pointer
		return root; 
	} 

	// method for inorder traversal of BST 
	protected static void inorder() { 
		inorder_Recursive(root); 
	} 

	// recursively traverse the BST  
	protected static void inorder_Recursive(Node root) { 
		Node x= root;
		if (x != null) { 
			inorder_Recursive(x.left); 
			System.out.println("--CAPTAIN:");
			System.out.println("\r\n"
	    			+ "		       ID: "+x.key+"\r\n"
	    			+ "		       Name: "+x.name+"\r\n"
	    			+ "		       Available:  "+x.available+"\r\n"
	    			+ "		       Rating Star: "+x.star+"");
			inorder_Recursive(x.right); 
		} 
	} 
	protected static String[] search(int key)  { 
		Node x = search_Recursive(root, key); 
		if (x!= null) {
			String[]arr1= {String.valueOf(x.key),x.name,x.available,String.valueOf(x.star)}; 
			return arr1;}
		else {
			String[]arr1= {"0","0","0","0"};
			return arr1;}
	} 
	protected static Node get(Integer key) {
		Node x=root;
		while(x !=null) {
			int cmp =key.compareTo(x.key);
			if (cmp<0) x= x.left;
			else if (cmp>0) x= x.right;
			else if (cmp==0) return x;
		}
		return null;
	}
	
	protected static String[] changer(int key,int r) {
		Node x = get(key);
		int a= x.key;
		int b= x.star;
		String c= x.name;
		if(root!=null && root.available.equals("True")&& r==0) {
			deleteKey(key);
			insert(a, c, "False", b);
			return new String[]{String.valueOf(a), c, "False", String.valueOf(b)};	}
		else if (root!=null && root.available.equals("False")&& r==1)
			{ insert(a, c, "True", b);
			return new String[]{String.valueOf(a), c, "True", String.valueOf(b)};	}
		else 
			{ return new String[]{"0","0","0","0"};}
	}
	
//	protected static Node changerRec(Node root,int key) {
//		// Base Cases: root is null or key is present at root 
//		if (root==null || root.key==key) 
//			return root; 
//		// val is greater than root's key 
//		if (root.key > key) 
//			return changerRec(root.left, key); 
//		// val is less than root's key 
//		return changerRec(root.right, key); 
//	} 
	
	protected static String[] IncStar(int key,String r) {
		Node x=root;
		int a= key;
		int b= x.star;
		String c= x.name;
		String d= x.available;
		System.out.println(a+b+c+d);
		if(x!=null && r.equals("1")) {
			deleteKey(key);
			b+= 1;
			insert(a, c, d, b);}
		return new String[]{String.valueOf(a), c, d, String.valueOf(b)}; 
	}

	//recursive insert function
	protected static Node search_Recursive(Node root, int key)  { 
		

		// Base Cases: root is null or key is present at root 
		if (root==null)
			return null; 
		if	(root.key==key) 
			return root; 
		// val is greater than root's key 
		if (root.key > key) 
			return search_Recursive(root.left, key); 
		// val is less than root's key 
		return search_Recursive(root.right, key); 
	} 


}

